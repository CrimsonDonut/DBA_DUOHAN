<?php

require __DIR__ . '/../config/db.php';

try {
    $pdo = getPdo();
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    http_response_code(500);
    die('Database connection failed.');
}

/*
 * Each report is a fixed query against the views / functions / audit table
 * created by db/week07_10_update.sql. Nothing here is built from user input.
 */
$reports = [
    'overdue' => [
        'title' => 'Overdue Loans',
        'note'  => 'View vw_overdue_loans: Overdue status, or Active past the due date.',
        'sql'   => 'SELECT borrow_id, borrower_no, borrower_name, borrow_date, due_date, status, days_overdue
                    FROM vw_overdue_loans
                    ORDER BY days_overdue DESC, borrow_id',
    ],
    'borrowers' => [
        'title' => 'Borrower Summary',
        'note'  => 'View vw_borrower_summary: every borrower, with a CASE-based standing.',
        'sql'   => 'SELECT borrower_no, full_name, borrower_type, transaction_count,
                           open_transactions, last_borrow_date, standing
                    FROM vw_borrower_summary
                    ORDER BY borrower_no',
    ],
    'equipment' => [
        'title' => 'Equipment Status',
        'note'  => 'View vw_equipment_status, plus fn_equipment_out() per item.',
        'sql'   => 'SELECT property_no, equipment_name, quantity_available, quantity_out,
                           fn_equipment_out(equipment_id) AS quantity_out_fn,
                           times_borrowed, stock_level
                    FROM vw_equipment_status
                    ORDER BY property_no',
    ],
    'details' => [
        'title' => 'Borrow Details',
        'note'  => 'View vw_borrow_details: one row per borrowed item.',
        'sql'   => "SELECT borrow_id, borrower_no, borrower_name, property_no, equipment_name, quantity,
                           TO_CHAR(borrow_date, 'Mon DD, YYYY') AS borrowed_on,
                           TO_CHAR(due_date, 'Mon DD, YYYY')    AS due_on,
                           status
                    FROM vw_borrow_details
                    ORDER BY borrow_id DESC, property_no",
    ],
    'monthly' => [
        'title' => 'Monthly Borrowing',
        'note'  => 'View vw_monthly_borrowing: grouped with DATE_TRUNC.',
        'sql'   => "SELECT TO_CHAR(borrow_month, 'Mon YYYY') AS month, transactions, total_items
                    FROM vw_monthly_borrowing
                    ORDER BY borrow_month",
    ],
    'audit' => [
        'title' => 'Audit Log',
        'note'  => 'Latest 50 changes recorded automatically by the audit triggers.',
        'sql'   => "SELECT audit_id, table_name, record_id, action_type, changed_by,
                           TO_CHAR(changed_at, 'Mon DD, YYYY HH24:MI:SS') AS changed_at,
                           old_data::text AS old_data, new_data::text AS new_data
                    FROM audit_log
                    ORDER BY audit_id DESC
                    LIMIT 50",
    ],
];

$current = $_GET['report'] ?? 'overdue';
if (!isset($reports[$current])) {
    $current = 'overdue';
}

$rows = [];
$error = null;
try {
    $rows = $pdo->query($reports[$current]['sql'])->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log('Report query failed: ' . $e->getMessage());
    $error = 'This report could not be loaded. Run db/week07_10_update.sql on the database first.';
}

function h($value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function headerLabel(string $name): string
{
    return ucfirst(str_replace('_', ' ', $name));
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Borrowing Reports</title>
    <style>
        :root {
            --border: #e2e2e2;
            --text: #2b2b2b;
            --muted: #6b6b6b;
            --accent: #2f6f4f;
            --bg-soft: #fafafa;
        }
        * { box-sizing: border-box; }
        body {
            font-family: Arial, sans-serif;
            color: var(--text);
            max-width: 1100px;
            margin: 40px auto;
            padding: 0 20px;
            line-height: 1.5;
        }
        h1, h2 { margin-bottom: 12px; }
        p.subtitle { color: var(--muted); margin-top: 0; margin-bottom: 28px; }
        .tabs { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 24px; }
        .tabs a {
            text-decoration: none;
            background: var(--bg-soft);
            border: 1px solid var(--border);
            border-radius: 6px;
            padding: 8px 12px;
            color: var(--text);
        }
        .tabs a.active { background: var(--accent); border-color: var(--accent); color: #fff; }
        section {
            padding: 20px;
            border: 1px solid var(--border);
            border-radius: 10px;
            background: #fff;
            overflow-x: auto;
        }
        table { width: 100%; border-collapse: collapse; font-size: 14px; }
        th, td { text-align: left; padding: 10px; border-bottom: 1px solid var(--border); vertical-align: top; }
        th { font-size: 12px; text-transform: uppercase; letter-spacing: 0.04em; color: var(--muted); }
        tr:hover td { background: var(--bg-soft); }
        td.json { font-family: monospace; font-size: 12px; max-width: 320px; word-break: break-all; }
        .note, .empty { color: var(--muted); }
        .error { color: #a33; }
        .back { display: inline-block; margin-bottom: 16px; color: var(--accent); }
    </style>
</head>
<body>
    <a class="back" href="crud_demo.php">&larr; Back to CRUD demo</a>
    <h1>Borrowing Reports</h1>
    <p class="subtitle">Read-only reports built from database views, functions and the audit log.</p>

    <nav class="tabs" aria-label="Reports">
        <?php foreach ($reports as $key => $report): ?>
            <a href="?report=<?= h(urlencode($key)) ?>" class="<?= $key === $current ? 'active' : '' ?>"><?= h($report['title']) ?></a>
        <?php endforeach; ?>
    </nav>

    <section>
        <h2><?= h($reports[$current]['title']) ?></h2>
        <p class="note"><?= h($reports[$current]['note']) ?></p>

        <?php if ($error !== null): ?>
            <p class="error"><?= h($error) ?></p>
        <?php elseif (empty($rows)): ?>
            <p class="empty">No rows to show.</p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <?php foreach (array_keys($rows[0]) as $column): ?>
                            <th><?= h(headerLabel($column)) ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($rows as $row): ?>
                        <tr>
                            <?php foreach ($row as $column => $value): ?>
                                <td class="<?= in_array($column, ['old_data', 'new_data'], true) ? 'json' : '' ?>"><?= h($value) ?></td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </section>
</body>
</html>
